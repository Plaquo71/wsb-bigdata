# Hadoop

This project is dedicated to WSB students of Databases and Big Data.
It includes instructions and simple examples of using Hadoop to processing and analyzing the data.